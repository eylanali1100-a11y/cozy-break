import { useEffect, useRef, useState } from 'react';
import { useTimer } from '@/react-app/hooks/useTimer';
import { useAchievements } from '@/react-app/hooks/useAchievements';
import TimerInput from '@/react-app/components/TimerInput';
import TimerPresets from '@/react-app/components/TimerPresets';
import ActionButton from '@/react-app/components/ActionButton';
import BreakReminder from '@/react-app/components/BreakReminder';
import CircularProgress from '@/react-app/components/CircularProgress';
import StreakDisplay from '@/react-app/components/StreakDisplay';
import GoalProgress from '@/react-app/components/GoalProgress';
import AchievementToast from '@/react-app/components/AchievementToast';
import EnhancedSettingsModal from '@/react-app/components/EnhancedSettingsModal';

export default function Home() {
  const {
    minutes,
    setMinutes,
    isRunning,
    start,
    stop,
    timeRemaining,
    showReminder,
    dismissReminder,
    snoozeReminder,
    alarmSound,
    setAlarmSound,
    currentExercise,
    streakData,
    breakDuration,
    setBreakDuration,
    breakTimeRemaining,
    isOnBreak,
  } = useTimer();

  const { newlyUnlocked, dismissNewlyUnlocked } = useAchievements();

  const [showSettings, setShowSettings] = useState(false);
  const [totalTime, setTotalTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Load Google Font
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    return () => {
      document.head.removeChild(link);
    };
  }, []);

  // Store total time when timer starts
  useEffect(() => {
    if (isRunning && timeRemaining === minutes * 60) {
      setTotalTime(minutes * 60);
    }
  }, [isRunning, timeRemaining, minutes]);

  // Play alarm sound when reminder appears
  useEffect(() => {
    if (showReminder) {
      // Create audio element if it doesn't exist or if sound changed
      if (!audioRef.current || audioRef.current.src !== alarmSound) {
        if (audioRef.current) {
          audioRef.current.pause();
        }
        audioRef.current = new Audio(alarmSound);
        audioRef.current.volume = 0.6;
        audioRef.current.loop = true;
      }
      
      // Play the alarm sound
      audioRef.current.play().catch(err => {
        console.log('Audio playback failed:', err);
      });
    } else {
      // Stop the alarm when reminder is dismissed
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    }
  }, [showReminder, alarmSound]);

  return (
    <div className="min-h-screen bg-[var(--color-background)] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8 relative">
          <button
            onClick={() => setShowSettings(true)}
            className="absolute right-0 top-0 text-[var(--color-text)] hover:text-[var(--color-primary-hover)] transition-colors"
            title="Settings"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
          
          <h1 className="text-4xl font-bold text-[var(--color-text)] mb-4">
            CozyBreak
          </h1>
          <p className="text-lg text-[var(--color-text)] opacity-80">
            Take tiny breaks to rest your eyes! 👀✨
          </p>
        </div>

        {/* Goal Progress */}
        <GoalProgress />

        {/* Streak Display */}
        <StreakDisplay 
          currentStreak={streakData.currentStreak}
          totalBreaks={streakData.totalBreaks}
          longestStreak={streakData.longestStreak}
        />

        <div className="bg-[var(--color-card-bg)] rounded-3xl p-8 shadow-xl">
          {isRunning ? (
            <CircularProgress 
              timeRemaining={timeRemaining} 
              totalTime={totalTime}
            />
          ) : null}
          
          {!isRunning && (
            <div className="space-y-6">
              <TimerPresets
                onSelectPreset={setMinutes}
                disabled={isRunning}
                currentMinutes={minutes}
              />
              
              <div className="text-center text-sm text-[var(--color-text)] opacity-60">
                or set custom duration
              </div>

              <TimerInput
                value={minutes}
                onChange={setMinutes}
                disabled={isRunning}
              />
              
              <div className="flex justify-center">
                <ActionButton onClick={start} disabled={minutes === 0}>
                  Start Timer
                </ActionButton>
              </div>
            </div>
          )}

          {isRunning && (
            <div className="flex justify-center">
              <ActionButton onClick={stop} variant="secondary">
                Stop
              </ActionButton>
            </div>
          )}
        </div>

        <div className="text-center mt-8 text-sm text-[var(--color-text)] opacity-60">
          Set a timer to remind yourself to take regular eye breaks
        </div>
      </div>

      <BreakReminder
        isVisible={showReminder}
        onDone={dismissReminder}
        onLater={snoozeReminder}
        exercise={currentExercise}
        breakTimeRemaining={breakTimeRemaining}
        isOnBreak={isOnBreak}
      />

      <AchievementToast
        achievements={newlyUnlocked}
        onDismiss={dismissNewlyUnlocked}
      />

      <EnhancedSettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        currentAlarmSound={alarmSound}
        onSelectAlarmSound={setAlarmSound}
        breakDuration={breakDuration}
        onSetBreakDuration={setBreakDuration}
      />
    </div>
  );
}
