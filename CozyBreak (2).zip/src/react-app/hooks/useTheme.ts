import { useState, useEffect } from 'react';

export type Theme = 'cozy' | 'ocean' | 'forest' | 'sunset' | 'minimal';

interface ThemeConfig {
  name: string;
  colors: {
    primary: string;
    primaryHover: string;
    background: string;
    cardBg: string;
    text: string;
    accent: string;
    border: string;
  };
}

const THEMES: Record<Theme, ThemeConfig> = {
  cozy: {
    name: 'Cozy Pink',
    colors: {
      primary: '#FFC0CB',
      primaryHover: '#FF91A4',
      background: '#FDF6EC',
      cardBg: '#FFFFFF',
      text: '#333333',
      accent: '#FFE4E9',
      border: '#FFC0CB'
    }
  },
  ocean: {
    name: 'Ocean Blue',
    colors: {
      primary: '#4FC3F7',
      primaryHover: '#29B6F6',
      background: '#E3F2FD',
      cardBg: '#FFFFFF',
      text: '#1565C0',
      accent: '#E1F5FE',
      border: '#4FC3F7'
    }
  },
  forest: {
    name: 'Forest Green',
    colors: {
      primary: '#66BB6A',
      primaryHover: '#4CAF50',
      background: '#E8F5E8',
      cardBg: '#FFFFFF',
      text: '#2E7D32',
      accent: '#C8E6C9',
      border: '#66BB6A'
    }
  },
  sunset: {
    name: 'Sunset Orange',
    colors: {
      primary: '#FF8A65',
      primaryHover: '#FF7043',
      background: '#FFF3E0',
      cardBg: '#FFFFFF',
      text: '#D84315',
      accent: '#FFCCBC',
      border: '#FF8A65'
    }
  },
  minimal: {
    name: 'Minimal Gray',
    colors: {
      primary: '#9E9E9E',
      primaryHover: '#757575',
      background: '#FAFAFA',
      cardBg: '#FFFFFF',
      text: '#424242',
      accent: '#F5F5F5',
      border: '#9E9E9E'
    }
  }
};

export function useTheme() {
  const [currentTheme, setCurrentTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('cozybreak_theme');
    return (saved as Theme) || 'cozy';
  });

  // Save theme to localStorage
  useEffect(() => {
    localStorage.setItem('cozybreak_theme', currentTheme);
  }, [currentTheme]);

  // Apply CSS variables to document root
  useEffect(() => {
    const theme = THEMES[currentTheme];
    const root = document.documentElement;
    
    root.style.setProperty('--color-primary', theme.colors.primary);
    root.style.setProperty('--color-primary-hover', theme.colors.primaryHover);
    root.style.setProperty('--color-background', theme.colors.background);
    root.style.setProperty('--color-card-bg', theme.colors.cardBg);
    root.style.setProperty('--color-text', theme.colors.text);
    root.style.setProperty('--color-accent', theme.colors.accent);
    root.style.setProperty('--color-border', theme.colors.border);
  }, [currentTheme]);

  return {
    currentTheme,
    setTheme: setCurrentTheme,
    themes: THEMES,
    themeConfig: THEMES[currentTheme]
  };
}
