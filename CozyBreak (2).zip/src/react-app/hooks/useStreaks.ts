import { useState, useEffect } from 'react';
import { useGoals } from './useGoals';

interface StreakData {
  currentStreak: number;
  lastBreakDate: string;
  totalBreaks: number;
  longestStreak: number;
}

export function useStreaks() {
  const { recordDailyBreak, recordWeeklyBreak } = useGoals();
  
  const [streakData, setStreakData] = useState<StreakData>(() => {
    const saved = localStorage.getItem('cozybreak_streaks');
    return saved ? JSON.parse(saved) : {
      currentStreak: 0,
      lastBreakDate: '',
      totalBreaks: 0,
      longestStreak: 0
    };
  });

  // Save to localStorage whenever streakData changes
  useEffect(() => {
    localStorage.setItem('cozybreak_streaks', JSON.stringify(streakData));
  }, [streakData]);

  const recordBreak = () => {
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toDateString();
    
    setStreakData(prev => {
      let newStreak = prev.currentStreak;
      
      // If this is the first break ever, or it's a new day
      if (!prev.lastBreakDate || prev.lastBreakDate === yesterday) {
        // Continue or start streak
        if (prev.lastBreakDate === yesterday) {
          newStreak = prev.currentStreak + 1;
        } else if (!prev.lastBreakDate) {
          newStreak = 1;
        } else {
          // Gap in days, reset streak
          newStreak = 1;
        }
      } else if (prev.lastBreakDate === today) {
        // Already took a break today, don't change streak but increment total
        newStreak = prev.currentStreak;
      } else {
        // More than one day gap, reset streak
        newStreak = 1;
      }

      const newLongestStreak = Math.max(prev.longestStreak, newStreak);

      const updatedData = {
        currentStreak: newStreak,
        lastBreakDate: today,
        totalBreaks: prev.totalBreaks + 1,
        longestStreak: newLongestStreak
      };

      // Record for goals tracking
      recordDailyBreak();
      recordWeeklyBreak();

      return updatedData;
    });
  };

  return {
    ...streakData,
    recordBreak
  };
}
