import { useState, useEffect } from 'react';

interface GoalData {
  dailyGoal: number;
  weeklyGoal: number;
}

export function useGoals() {
  const [goalData, setGoalData] = useState<GoalData>(() => {
    const saved = localStorage.getItem('cozybreak_goals');
    return saved ? JSON.parse(saved) : {
      dailyGoal: 3,
      weeklyGoal: 21
    };
  });

  // Save to localStorage whenever goalData changes
  useEffect(() => {
    localStorage.setItem('cozybreak_goals', JSON.stringify(goalData));
  }, [goalData]);

  const setDailyGoal = (goal: number) => {
    if (goal >= 1 && goal <= 20) {
      setGoalData(prev => ({ ...prev, dailyGoal: goal }));
    }
  };

  const setWeeklyGoal = (goal: number) => {
    if (goal >= 1 && goal <= 140) {
      setGoalData(prev => ({ ...prev, weeklyGoal: goal }));
    }
  };

  const getTodayBreaks = () => {
    const today = new Date().toDateString();
    const saved = localStorage.getItem('cozybreak_daily_count');
    const dailyData = saved ? JSON.parse(saved) : { date: '', count: 0 };
    
    return dailyData.date === today ? dailyData.count : 0;
  };

  const recordDailyBreak = () => {
    const today = new Date().toDateString();
    const saved = localStorage.getItem('cozybreak_daily_count');
    const dailyData = saved ? JSON.parse(saved) : { date: '', count: 0 };
    
    if (dailyData.date === today) {
      dailyData.count += 1;
    } else {
      dailyData.date = today;
      dailyData.count = 1;
    }
    
    localStorage.setItem('cozybreak_daily_count', JSON.stringify(dailyData));
    return dailyData.count;
  };

  const getWeeklyBreaks = () => {
    // Get breaks for the last 7 days
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      dates.push(date.toDateString());
    }
    
    const saved = localStorage.getItem('cozybreak_weekly_count');
    const weeklyData = saved ? JSON.parse(saved) : {};
    
    return dates.reduce((total, date) => total + (weeklyData[date] || 0), 0);
  };

  const recordWeeklyBreak = () => {
    const today = new Date().toDateString();
    const saved = localStorage.getItem('cozybreak_weekly_count');
    const weeklyData = saved ? JSON.parse(saved) : {};
    
    weeklyData[today] = (weeklyData[today] || 0) + 1;
    
    // Clean up old entries (keep only last 30 days)
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 30);
    
    Object.keys(weeklyData).forEach(date => {
      if (new Date(date) < cutoffDate) {
        delete weeklyData[date];
      }
    });
    
    localStorage.setItem('cozybreak_weekly_count', JSON.stringify(weeklyData));
    return getWeeklyBreaks();
  };

  return {
    ...goalData,
    setDailyGoal,
    setWeeklyGoal,
    getTodayBreaks,
    getWeeklyBreaks,
    recordDailyBreak,
    recordWeeklyBreak
  };
}
