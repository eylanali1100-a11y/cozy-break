import { useState, useEffect, useRef } from 'react';
import { useStreaks } from './useStreaks';
import { useBreakExercises, type BreakExercise } from './useBreakExercises';
import { useNotifications } from './useNotifications';
import { useAchievements } from './useAchievements';
import { useTheme } from './useTheme';

export interface UseTimerReturn {
  minutes: number;
  setMinutes: (minutes: number) => void;
  isRunning: boolean;
  start: () => void;
  stop: () => void;
  timeRemaining: number;
  showReminder: boolean;
  dismissReminder: () => void;
  snoozeReminder: () => void;
  alarmSound: string;
  setAlarmSound: (sound: string) => void;
  currentExercise: BreakExercise | null;
  streakData: {
    currentStreak: number;
    totalBreaks: number;
    longestStreak: number;
  };
  breakDuration: number;
  setBreakDuration: (duration: number) => void;
  breakTimeRemaining: number;
  isOnBreak: boolean;
}

const ALARM_SOUNDS = {
  default: 'https://assets.mixkit.co/active_storage/sfx/2860/2860-preview.mp3',
  beep: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3',
  chime: 'https://assets.mixkit.co/active_storage/sfx/1465/1465-preview.mp3',
  bell: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
  ding: 'https://assets.mixkit.co/active_storage/sfx/316/316-preview.mp3',
  notification: 'https://assets.mixkit.co/active_storage/sfx/2354/2354-preview.mp3',
  gentle: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3',
  zen: 'https://assets.mixkit.co/active_storage/sfx/1464/1464-preview.mp3',
  soft: 'https://assets.mixkit.co/active_storage/sfx/2357/2357-preview.mp3',
  nature: 'https://assets.mixkit.co/active_storage/sfx/578/578-preview.mp3',
  warm: 'https://assets.mixkit.co/active_storage/sfx/2870/2870-preview.mp3',
  crystal: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
};

export { ALARM_SOUNDS };

export function useTimer(): UseTimerReturn {
  const { currentStreak, totalBreaks, longestStreak, recordBreak } = useStreaks();
  const { getRandomExercise, selectedCategories } = useBreakExercises();
  const { sendBreakReminder } = useNotifications();
  const { checkAchievements } = useAchievements();
  const { currentTheme } = useTheme();
  
  // Load saved values from localStorage
  const [minutes, setMinutes] = useState<number>(() => {
    const saved = localStorage.getItem('cozybreak_minutes');
    return saved ? parseInt(saved) : 20;
  });

  const [alarmSound, setAlarmSound] = useState<string>(() => {
    const saved = localStorage.getItem('cozybreak_alarm');
    return saved || ALARM_SOUNDS.default;
  });

  const [breakDuration, setBreakDuration] = useState<number>(() => {
    const saved = localStorage.getItem('cozybreak_break_duration');
    return saved ? parseInt(saved) : 2; // 2 minutes default
  });

  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [showReminder, setShowReminder] = useState<boolean>(false);
  const [isOnBreak, setIsOnBreak] = useState<boolean>(false);
  const [breakTimeRemaining, setBreakTimeRemaining] = useState<number>(0);
  const [currentExercise, setCurrentExercise] = useState<BreakExercise | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const breakIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Save minutes to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cozybreak_minutes', minutes.toString());
  }, [minutes]);

  // Save alarm sound to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cozybreak_alarm', alarmSound);
  }, [alarmSound]);

  // Save break duration to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cozybreak_break_duration', breakDuration.toString());
  }, [breakDuration]);

  const start = () => {
    if (minutes > 0) {
      setTimeRemaining(minutes * 60); // Convert to seconds
      setIsRunning(true);
      setShowReminder(false);
    }
  };

  const stop = () => {
    setIsRunning(false);
    setTimeRemaining(0);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  };

  const dismissReminder = () => {
    setShowReminder(false);
    setIsRunning(false);
    setTimeRemaining(0);
    setCurrentExercise(null);
    setIsOnBreak(false);
    setBreakTimeRemaining(0);
    
    if (breakIntervalRef.current) {
      clearInterval(breakIntervalRef.current);
    }
    
    recordBreak(); // Record the completed break for streak tracking
    
    // Check achievements after recording break
    checkAchievements({
      totalBreaks: totalBreaks + 1,
      currentStreak,
      longestStreak,
      currentTheme,
      selectedCategories,
      alarmSound
    });
  };

  const snoozeReminder = () => {
    setShowReminder(false);
    // Snooze for 5 minutes
    setTimeRemaining(5 * 60);
    setIsRunning(true);
  };

  useEffect(() => {
    if (isRunning && timeRemaining > 0) {
      intervalRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            setShowReminder(true);
            setCurrentExercise(getRandomExercise()); // Get a random exercise for the break
            setIsOnBreak(true);
            setBreakTimeRemaining(breakDuration * 60); // Convert to seconds
            
            // Send desktop notification
            sendBreakReminder();
            
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
      };
    }
  }, [isRunning, timeRemaining]);

  // Break timer effect
  useEffect(() => {
    if (isOnBreak && breakTimeRemaining > 0) {
      breakIntervalRef.current = setInterval(() => {
        setBreakTimeRemaining((prev) => {
          if (prev <= 1) {
            setIsOnBreak(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (breakIntervalRef.current) {
          clearInterval(breakIntervalRef.current);
        }
      };
    }
  }, [isOnBreak, breakTimeRemaining]);

  return {
    minutes,
    setMinutes,
    isRunning,
    start,
    stop,
    timeRemaining,
    showReminder,
    dismissReminder,
    snoozeReminder,
    alarmSound,
    setAlarmSound,
    currentExercise,
    streakData: {
      currentStreak,
      totalBreaks,
      longestStreak
    },
    breakDuration,
    setBreakDuration,
    breakTimeRemaining,
    isOnBreak
  };
}
