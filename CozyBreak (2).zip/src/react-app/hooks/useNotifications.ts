import { useState, useEffect } from 'react';

export function useNotifications() {
  const [permissionGranted, setPermissionGranted] = useState<boolean>(() => {
    return Notification.permission === 'granted';
  });

  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('cozybreak_notifications');
    return saved ? JSON.parse(saved) : false;
  });

  // Save notification preference to localStorage
  useEffect(() => {
    localStorage.setItem('cozybreak_notifications', JSON.stringify(notificationsEnabled));
  }, [notificationsEnabled]);

  const requestPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setPermissionGranted(permission === 'granted');
      return permission === 'granted';
    }
    return false;
  };

  const sendNotification = (title: string, options?: NotificationOptions) => {
    if (notificationsEnabled && permissionGranted && 'Notification' in window) {
      try {
        const notification = new Notification(title, {
          icon: 'https://mocha-cdn.com/favicon.ico',
          badge: 'https://mocha-cdn.com/apple-touch-icon.png',
          ...options
        });

        // Auto-close after 10 seconds
        setTimeout(() => {
          notification.close();
        }, 10000);

        return notification;
      } catch (error) {
        console.warn('Failed to send notification:', error);
      }
    }
    return null;
  };

  const sendBreakReminder = () => {
    return sendNotification('Time for a break! 👀', {
      body: 'Take a moment to rest your eyes and stretch.',
      tag: 'break-reminder'
    });
  };

  const toggleNotifications = async () => {
    if (!notificationsEnabled && !permissionGranted) {
      const granted = await requestPermission();
      if (!granted) {
        return false;
      }
    }
    
    setNotificationsEnabled(!notificationsEnabled);
    return true;
  };

  return {
    permissionGranted,
    notificationsEnabled,
    requestPermission,
    sendNotification,
    sendBreakReminder,
    toggleNotifications
  };
}
