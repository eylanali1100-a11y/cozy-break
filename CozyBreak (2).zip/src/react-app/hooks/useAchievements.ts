import { useState, useEffect } from 'react';

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'streak' | 'usage' | 'customization' | 'milestone';
  checkCondition: (data: {
    totalBreaks: number;
    currentStreak: number;
    longestStreak: number;
    currentTheme: string;
    selectedCategories: string[];
    alarmSound: string;
  }) => boolean;
}

const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first-break',
    name: 'First Break',
    description: 'Take your very first eye break',
    icon: '🌟',
    category: 'milestone',
    checkCondition: (data) => data.totalBreaks >= 1
  },
  {
    id: 'week-warrior',
    name: 'Week Warrior',
    description: 'Maintain a 7-day break streak',
    icon: '🔥',
    category: 'streak',
    checkCondition: (data) => data.currentStreak >= 7
  },
  {
    id: 'century-club',
    name: 'Century Club',
    description: 'Complete 100 total breaks',
    icon: '💯',
    category: 'usage',
    checkCondition: (data) => data.totalBreaks >= 100
  },
  {
    id: 'theme-explorer',
    name: 'Theme Explorer',
    description: 'Try a different theme',
    icon: '🎨',
    category: 'customization',
    checkCondition: (data) => data.currentTheme !== 'cozy'
  },
  {
    id: 'dedication-master',
    name: 'Dedication Master',
    description: 'Reach a 30-day streak',
    icon: '👑',
    category: 'streak',
    checkCondition: (data) => data.currentStreak >= 30
  },
  {
    id: 'break-enthusiast',
    name: 'Break Enthusiast',
    description: 'Complete 25 breaks',
    icon: '⭐',
    category: 'usage',
    checkCondition: (data) => data.totalBreaks >= 25
  },
  {
    id: 'variety-seeker',
    name: 'Variety Seeker',
    description: 'Enable all break activity categories',
    icon: '🌈',
    category: 'customization',
    checkCondition: (data) => data.selectedCategories.length >= 3
  },
  {
    id: 'sound-perfectionist',
    name: 'Sound Perfectionist',
    description: 'Change your alarm sound',
    icon: '🔊',
    category: 'customization',
    checkCondition: (data) => data.alarmSound !== 'https://assets.mixkit.co/active_storage/sfx/2860/2860-preview.mp3'
  },
  {
    id: 'consistency-champion',
    name: 'Consistency Champion',
    description: 'Maintain a 14-day streak',
    icon: '🏆',
    category: 'streak',
    checkCondition: (data) => data.currentStreak >= 14
  },
  {
    id: 'half-century',
    name: 'Half Century',
    description: 'Complete 50 breaks',
    icon: '🎯',
    category: 'usage',
    checkCondition: (data) => data.totalBreaks >= 50
  }
];

export function useAchievements() {
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => {
    const saved = localStorage.getItem('cozybreak_achievements');
    return saved ? JSON.parse(saved) : [];
  });

  const [newlyUnlocked, setNewlyUnlocked] = useState<Achievement[]>([]);

  // Save unlocked achievements to localStorage
  useEffect(() => {
    localStorage.setItem('cozybreak_achievements', JSON.stringify(unlockedAchievements));
  }, [unlockedAchievements]);

  const checkAchievements = (data: {
    totalBreaks: number;
    currentStreak: number;
    longestStreak: number;
    currentTheme: string;
    selectedCategories: string[];
    alarmSound: string;
  }) => {
    const newUnlocked: Achievement[] = [];
    
    ACHIEVEMENTS.forEach(achievement => {
      if (!unlockedAchievements.includes(achievement.id) && achievement.checkCondition(data)) {
        newUnlocked.push(achievement);
      }
    });

    if (newUnlocked.length > 0) {
      setUnlockedAchievements(prev => [...prev, ...newUnlocked.map(a => a.id)]);
      setNewlyUnlocked(newUnlocked);
      
      // Clear newly unlocked after 5 seconds
      setTimeout(() => {
        setNewlyUnlocked([]);
      }, 5000);
    }
  };

  const dismissNewlyUnlocked = () => {
    setNewlyUnlocked([]);
  };

  const getAchievementById = (id: string) => {
    return ACHIEVEMENTS.find(a => a.id === id);
  };

  const getUnlockedAchievements = () => {
    return ACHIEVEMENTS.filter(a => unlockedAchievements.includes(a.id));
  };

  const getLockedAchievements = () => {
    return ACHIEVEMENTS.filter(a => !unlockedAchievements.includes(a.id));
  };

  return {
    achievements: ACHIEVEMENTS,
    unlockedAchievements,
    newlyUnlocked,
    checkAchievements,
    dismissNewlyUnlocked,
    getAchievementById,
    getUnlockedAchievements,
    getLockedAchievements
  };
}
