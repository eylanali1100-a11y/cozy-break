import { useState, useEffect } from 'react';

export interface BreakExercise {
  id: string;
  name: string;
  icon: string;
  category: 'eyes' | 'stretch' | 'mindfulness';
  steps: { text: string; duration?: string }[];
}

const BREAK_EXERCISES: BreakExercise[] = [
  {
    id: 'classic-eyes',
    name: 'Classic Eye Rest',
    icon: '👀',
    category: 'eyes',
    steps: [
      { text: 'Close your eyes', duration: '10 seconds' },
      { text: 'Look far away', duration: '20 seconds' },
      { text: 'Roll eyes clockwise', duration: '5 times' }
    ]
  },
  {
    id: '20-20-20',
    name: '20-20-20 Rule',
    icon: '🔍',
    category: 'eyes',
    steps: [
      { text: 'Look at something 20 feet away', duration: '20 seconds' },
      { text: 'Blink slowly', duration: '10 times' },
      { text: 'Focus on different distances' }
    ]
  },
  {
    id: 'palming',
    name: 'Eye Palming',
    icon: '🙌',
    category: 'eyes',
    steps: [
      { text: 'Cover eyes gently with palms' },
      { text: 'Breathe deeply', duration: '30 seconds' },
      { text: 'Slowly remove hands and blink' }
    ]
  },
  {
    id: 'neck-stretch',
    name: 'Neck & Shoulder Stretch',
    icon: '🤸‍♀️',
    category: 'stretch',
    steps: [
      { text: 'Roll shoulders backwards', duration: '5 times' },
      { text: 'Tilt head side to side', duration: '3 times each' },
      { text: 'Gentle neck circles', duration: '3 times' }
    ]
  },
  {
    id: 'desk-stretch',
    name: 'Quick Desk Stretch',
    icon: '💪',
    category: 'stretch',
    steps: [
      { text: 'Stretch arms above head', duration: '10 seconds' },
      { text: 'Twist torso left and right', duration: '5 times each' },
      { text: 'Shrug shoulders up and down', duration: '5 times' }
    ]
  },
  {
    id: 'mindful-breathing',
    name: 'Mindful Breathing',
    icon: '🧘‍♀️',
    category: 'mindfulness',
    steps: [
      { text: 'Take a deep breath in', duration: '4 seconds' },
      { text: 'Hold your breath', duration: '4 seconds' },
      { text: 'Exhale slowly', duration: '6 seconds' },
      { text: 'Repeat 3 more times' }
    ]
  },
  {
    id: 'gratitude',
    name: 'Quick Gratitude',
    icon: '🙏',
    category: 'mindfulness',
    steps: [
      { text: 'Think of 3 things you\'re grateful for' },
      { text: 'Take a moment to smile' },
      { text: 'Feel the positive energy' }
    ]
  },
  {
    id: 'body-scan',
    name: 'Mini Body Scan',
    icon: '✨',
    category: 'mindfulness',
    steps: [
      { text: 'Notice tension in your shoulders' },
      { text: 'Relax your facial muscles' },
      { text: 'Feel your feet on the ground' },
      { text: 'Take 3 deep breaths' }
    ]
  }
];

export function useBreakExercises() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('cozybreak_exercise_categories');
    return saved ? JSON.parse(saved) : ['eyes', 'stretch', 'mindfulness'];
  });

  // Save selected categories to localStorage
  useEffect(() => {
    localStorage.setItem('cozybreak_exercise_categories', JSON.stringify(selectedCategories));
  }, [selectedCategories]);

  const getRandomExercise = (): BreakExercise => {
    const availableExercises = BREAK_EXERCISES.filter(exercise => 
      selectedCategories.includes(exercise.category)
    );
    
    if (availableExercises.length === 0) {
      // Fallback to classic eye exercise if no categories selected
      return BREAK_EXERCISES[0];
    }
    
    const randomIndex = Math.floor(Math.random() * availableExercises.length);
    return availableExercises[randomIndex];
  };

  const toggleCategory = (category: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(category)) {
        // Don't allow removing all categories
        if (prev.length === 1) return prev;
        return prev.filter(c => c !== category);
      } else {
        return [...prev, category];
      }
    });
  };

  return {
    exercises: BREAK_EXERCISES,
    selectedCategories,
    toggleCategory,
    getRandomExercise
  };
}
