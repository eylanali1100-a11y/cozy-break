interface TimerInputProps {
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

export default function TimerInput({ value, onChange, disabled = false }: TimerInputProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value) || 0;
    if (val >= 0 && val <= 999) {
      onChange(val);
    }
  };

  return (
    <div className="relative">
      <input
        type="number"
        min="1"
        max="999"
        value={value || ''}
        onChange={handleChange}
        disabled={disabled}
        placeholder="Minutes"
        className="w-full px-6 py-4 text-xl text-[var(--color-text)] bg-white rounded-2xl border-2 border-[var(--color-border)] focus:border-[var(--color-primary-hover)] focus:outline-none focus:ring-0 transition-colors duration-200 text-center font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
      />
    </div>
  );
}
