import { ALARM_SOUNDS } from '@/react-app/hooks/useTimer';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAlarmSound: string;
  onSelectAlarmSound: (sound: string) => void;
}

export default function SettingsModal({ 
  isOpen, 
  onClose, 
  currentAlarmSound, 
  onSelectAlarmSound 
}: SettingsModalProps) {
  if (!isOpen) return null;

  const alarmOptions = [
    { name: 'Default Alert', value: ALARM_SOUNDS.default },
    { name: 'Beep', value: ALARM_SOUNDS.beep },
    { name: 'Chime', value: ALARM_SOUNDS.chime },
    { name: 'Bell', value: ALARM_SOUNDS.bell },
    { name: 'Ding', value: ALARM_SOUNDS.ding },
    { name: 'Notification', value: ALARM_SOUNDS.notification },
    { name: 'Gentle', value: ALARM_SOUNDS.gentle },
    { name: 'Zen', value: ALARM_SOUNDS.zen },
    { name: 'Soft Tone', value: ALARM_SOUNDS.soft },
    { name: 'Nature Sound', value: ALARM_SOUNDS.nature },
    { name: 'Warm Bell', value: ALARM_SOUNDS.warm },
    { name: 'Crystal Chime', value: ALARM_SOUNDS.crystal },
  ];

  const playPreview = (soundUrl: string) => {
    const audio = new Audio(soundUrl);
    audio.volume = 0.6;
    audio.play().catch(err => console.log('Audio preview failed:', err));
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl p-8 max-w-md w-full mx-4 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-[#333333]">Settings</h2>
          <button
            onClick={onClose}
            className="text-[#333333] hover:text-[#FF91A4] text-2xl font-bold transition-colors"
          >
            ×
          </button>
        </div>

        <div className="mb-6">
          <h3 className="text-lg font-semibold text-[#333333] mb-4">Alarm Sound</h3>
          <div className="space-y-3">
            {alarmOptions.map((option) => (
              <div
                key={option.value}
                className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  currentAlarmSound === option.value
                    ? 'border-[#FFC0CB] bg-[#FFF5F7]'
                    : 'border-[#FFE4E9] hover:border-[#FFC0CB]'
                }`}
                onClick={() => onSelectAlarmSound(option.value)}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      currentAlarmSound === option.value
                        ? 'border-[#FFC0CB]'
                        : 'border-gray-300'
                    }`}
                  >
                    {currentAlarmSound === option.value && (
                      <div className="w-3 h-3 rounded-full bg-[#FFC0CB]" />
                    )}
                  </div>
                  <span className="text-[#333333] font-medium">{option.name}</span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    playPreview(option.value);
                  }}
                  className="text-[#FFC0CB] hover:text-[#FF91A4] text-2xl transition-colors"
                  title="Preview"
                >
                  ▶
                </button>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full px-6 py-3 bg-[#FFC0CB] hover:bg-[#FF91A4] text-[#333333] font-semibold rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95"
        >
          Done
        </button>
      </div>
    </div>
  );
}
