interface CircularProgressProps {
  timeRemaining: number;
  totalTime: number;
}

export default function CircularProgress({ timeRemaining, totalTime }: CircularProgressProps) {
  const percentage = totalTime > 0 ? (timeRemaining / totalTime) * 100 : 0;
  const strokeDashoffset = 565.48 - (565.48 * percentage) / 100; // Circumference of circle with r=90

  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;

  return (
    <div className="flex justify-center items-center mb-8">
      <div className="relative w-64 h-64">
        <svg className="transform -rotate-90 w-full h-full" viewBox="0 0 200 200">
          {/* Background circle */}
          <circle
            cx="100"
            cy="100"
            r="90"
            stroke="var(--color-accent)"
            strokeWidth="12"
            fill="none"
          />
          {/* Progress circle */}
          <circle
            cx="100"
            cy="100"
            r="90"
            stroke="var(--color-primary)"
            strokeWidth="12"
            fill="none"
            strokeDasharray="565.48"
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-linear"
            style={{
              filter: `drop-shadow(0 0 8px var(--color-primary))`,
            }}
          />
        </svg>
        {/* Timer text in center */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-5xl font-bold text-[var(--color-text)] font-mono tracking-wider">
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </div>
          <p className="text-sm text-[var(--color-text)] opacity-70 mt-2">
            until next break
          </p>
        </div>
      </div>
    </div>
  );
}
