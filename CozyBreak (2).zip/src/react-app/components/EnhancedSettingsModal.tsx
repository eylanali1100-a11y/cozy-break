import { ALARM_SOUNDS } from '@/react-app/hooks/useTimer';
import { useTheme, type Theme } from '@/react-app/hooks/useTheme';
import { useBreakExercises } from '@/react-app/hooks/useBreakExercises';
import { useGoals } from '@/react-app/hooks/useGoals';
import { useNotifications } from '@/react-app/hooks/useNotifications';
import AchievementsModal from './AchievementsModal';
import { useState } from 'react';

interface EnhancedSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAlarmSound: string;
  onSelectAlarmSound: (sound: string) => void;
  breakDuration: number;
  onSetBreakDuration: (duration: number) => void;
}

export default function EnhancedSettingsModal({ 
  isOpen, 
  onClose, 
  currentAlarmSound, 
  onSelectAlarmSound,
  breakDuration,
  onSetBreakDuration 
}: EnhancedSettingsModalProps) {
  const { currentTheme, setTheme, themes } = useTheme();
  const { selectedCategories, toggleCategory } = useBreakExercises();
  const { dailyGoal, weeklyGoal, setDailyGoal, setWeeklyGoal } = useGoals();
  const { notificationsEnabled, toggleNotifications, permissionGranted } = useNotifications();
  const [showAchievements, setShowAchievements] = useState(false);

  if (!isOpen) return null;

  const alarmOptions = [
    { name: 'Default Alert', value: ALARM_SOUNDS.default },
    { name: 'Beep', value: ALARM_SOUNDS.beep },
    { name: 'Chime', value: ALARM_SOUNDS.chime },
    { name: 'Bell', value: ALARM_SOUNDS.bell },
    { name: 'Ding', value: ALARM_SOUNDS.ding },
    { name: 'Notification', value: ALARM_SOUNDS.notification },
    { name: 'Gentle', value: ALARM_SOUNDS.gentle },
    { name: 'Zen', value: ALARM_SOUNDS.zen },
    { name: 'Soft Tone', value: ALARM_SOUNDS.soft },
    { name: 'Nature Sound', value: ALARM_SOUNDS.nature },
    { name: 'Warm Bell', value: ALARM_SOUNDS.warm },
    { name: 'Crystal Chime', value: ALARM_SOUNDS.crystal },
  ];

  const categoryOptions = [
    { id: 'eyes', name: 'Eye Exercises', icon: '👀', description: 'Rest and strengthen your eyes' },
    { id: 'stretch', name: 'Physical Stretches', icon: '🤸‍♀️', description: 'Neck, shoulder and body stretches' },
    { id: 'mindfulness', name: 'Mindfulness', icon: '🧘‍♀️', description: 'Breathing and mental wellness' }
  ];

  const playPreview = (soundUrl: string) => {
    const audio = new Audio(soundUrl);
    audio.volume = 0.6;
    audio.play().catch(err => console.log('Audio preview failed:', err));
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-[var(--color-card-bg)] rounded-3xl p-8 max-w-2xl w-full mx-4 shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-[var(--color-text)]">Settings</h2>
          <button
            onClick={onClose}
            className="text-[var(--color-text)] hover:text-[var(--color-primary-hover)] text-2xl font-bold transition-colors"
          >
            ×
          </button>
        </div>

        {/* Theme Selection */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">Theme</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {Object.entries(themes).map(([themeKey, theme]) => (
              <button
                key={themeKey}
                onClick={() => setTheme(themeKey as Theme)}
                className={`p-4 rounded-xl border-2 transition-all ${
                  currentTheme === themeKey
                    ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                    : 'border-gray-200 hover:border-[var(--color-primary)]'
                }`}
              >
                <div 
                  className="w-full h-8 rounded-lg mb-2"
                  style={{ backgroundColor: theme.colors.primary }}
                />
                <div className="text-sm font-medium text-[var(--color-text)]">
                  {theme.name}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Break Exercise Categories */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">Break Activities</h3>
          <div className="space-y-3">
            {categoryOptions.map((category) => (
              <div
                key={category.id}
                onClick={() => toggleCategory(category.id)}
                className={`flex items-center p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedCategories.includes(category.id)
                    ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                    : 'border-gray-200 hover:border-[var(--color-primary)]'
                }`}
              >
                <div className="flex items-center gap-3 flex-1">
                  <span className="text-2xl">{category.icon}</span>
                  <div>
                    <div className="font-medium text-[var(--color-text)]">{category.name}</div>
                    <div className="text-sm text-[var(--color-text)] opacity-70">{category.description}</div>
                  </div>
                </div>
                <div
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                    selectedCategories.includes(category.id)
                      ? 'border-[var(--color-primary)] bg-[var(--color-primary)]'
                      : 'border-gray-300'
                  }`}
                >
                  {selectedCategories.includes(category.id) && (
                    <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Break Duration Setting */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">Break Duration</h3>
          <div className="grid grid-cols-4 gap-3">
            {[1, 2, 3, 5].map((duration) => (
              <button
                key={duration}
                onClick={() => onSetBreakDuration(duration)}
                className={`p-3 rounded-xl border-2 text-center transition-all ${
                  breakDuration === duration
                    ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                    : 'border-gray-200 hover:border-[var(--color-primary)]'
                }`}
              >
                <div className="font-semibold text-[var(--color-text)]">{duration}m</div>
              </button>
            ))}
          </div>
          <div className="text-xs text-[var(--color-text)] opacity-70 mt-2">
            How long your break reminder timer should run
          </div>
        </div>

        {/* Goals Setting */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">Daily & Weekly Goals</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                Daily Break Goal
              </label>
              <div className="flex gap-2">
                {[2, 3, 4, 5, 6].map((goal) => (
                  <button
                    key={goal}
                    onClick={() => setDailyGoal(goal)}
                    className={`px-3 py-2 rounded-lg border-2 text-sm transition-all ${
                      dailyGoal === goal
                        ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                        : 'border-gray-200 hover:border-[var(--color-primary)]'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[var(--color-text)] mb-2">
                Weekly Break Goal
              </label>
              <div className="flex gap-2">
                {[14, 21, 28, 35, 42].map((goal) => (
                  <button
                    key={goal}
                    onClick={() => setWeeklyGoal(goal)}
                    className={`px-3 py-2 rounded-lg border-2 text-sm transition-all ${
                      weeklyGoal === goal
                        ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                        : 'border-gray-200 hover:border-[var(--color-primary)]'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Notifications Setting */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">Notifications</h3>
          <div
            onClick={toggleNotifications}
            className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer transition-all ${
              notificationsEnabled
                ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                : 'border-gray-200 hover:border-[var(--color-primary)]'
            }`}
          >
            <div>
              <div className="font-medium text-[var(--color-text)]">Desktop Notifications</div>
              <div className="text-sm text-[var(--color-text)] opacity-70">
                Get notified even when in other tabs
              </div>
            </div>
            <div className={`w-12 h-6 rounded-full transition-colors ${
              notificationsEnabled ? 'bg-[var(--color-primary)]' : 'bg-gray-300'
            }`}>
              <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${
                notificationsEnabled ? 'translate-x-7' : 'translate-x-1'
              } mt-0.5`} />
            </div>
          </div>
          {!permissionGranted && notificationsEnabled && (
            <div className="text-xs text-orange-600 mt-2">
              Please allow notifications in your browser settings
            </div>
          )}
        </div>

        {/* Achievements Button */}
        <div className="mb-8">
          <button
            onClick={() => setShowAchievements(true)}
            className="w-full p-4 bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-primary-hover)] text-[var(--color-text)] font-semibold rounded-xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95"
          >
            🏆 View Achievements
          </button>
        </div>

        {/* Alarm Sound Selection */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">Alarm Sound</h3>
          <div className="space-y-3 max-h-60 overflow-y-auto">
            {alarmOptions.map((option) => (
              <div
                key={option.value}
                className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  currentAlarmSound === option.value
                    ? 'border-[var(--color-primary)] bg-[var(--color-accent)]'
                    : 'border-gray-200 hover:border-[var(--color-primary)]'
                }`}
                onClick={() => onSelectAlarmSound(option.value)}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      currentAlarmSound === option.value
                        ? 'border-[var(--color-primary)]'
                        : 'border-gray-300'
                    }`}
                  >
                    {currentAlarmSound === option.value && (
                      <div className="w-3 h-3 rounded-full bg-[var(--color-primary)]" />
                    )}
                  </div>
                  <span className="text-[var(--color-text)] font-medium">{option.name}</span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    playPreview(option.value);
                  }}
                  className="text-[var(--color-primary)] hover:text-[var(--color-primary-hover)] text-2xl transition-colors"
                  title="Preview"
                >
                  ▶
                </button>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full px-6 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary-hover)] text-[var(--color-text)] font-semibold rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95"
        >
          Done
        </button>
      </div>

      <AchievementsModal
        isOpen={showAchievements}
        onClose={() => setShowAchievements(false)}
      />
    </div>
  );
}
