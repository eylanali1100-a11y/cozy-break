import { useAchievements } from '@/react-app/hooks/useAchievements';

interface AchievementsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AchievementsModal({ isOpen, onClose }: AchievementsModalProps) {
  const { getUnlockedAchievements, getLockedAchievements } = useAchievements();
  
  if (!isOpen) return null;

  const unlockedAchievements = getUnlockedAchievements();
  const lockedAchievements = getLockedAchievements();

  const categoryColors = {
    streak: '#FF6B6B',
    usage: '#4ECDC4', 
    customization: '#45B7D1',
    milestone: '#FFA726'
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-[var(--color-card-bg)] rounded-3xl p-8 max-w-2xl w-full mx-4 shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-[var(--color-text)]">Achievements</h2>
          <button
            onClick={onClose}
            className="text-[var(--color-text)] hover:text-[var(--color-primary-hover)] text-2xl font-bold transition-colors"
          >
            ×
          </button>
        </div>

        <div className="mb-6">
          <div className="text-center p-4 bg-[var(--color-accent)] rounded-xl">
            <div className="text-3xl font-bold text-[var(--color-primary)]">
              {unlockedAchievements.length}
            </div>
            <div className="text-sm text-[var(--color-text)] opacity-70">
              Achievements Unlocked
            </div>
          </div>
        </div>

        {/* Unlocked Achievements */}
        {unlockedAchievements.length > 0 && (
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4 flex items-center gap-2">
              <span>🏆</span> Unlocked
            </h3>
            <div className="grid gap-3">
              {unlockedAchievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className="flex items-center p-4 bg-[var(--color-accent)] rounded-xl border-2 border-[var(--color-primary)]"
                >
                  <div className="text-3xl mr-4">{achievement.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-[var(--color-text)]">
                        {achievement.name}
                      </h4>
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: categoryColors[achievement.category] }}
                        title={achievement.category}
                      />
                    </div>
                    <p className="text-sm text-[var(--color-text)] opacity-70">
                      {achievement.description}
                    </p>
                  </div>
                  <div className="text-2xl">✅</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Locked Achievements */}
        {lockedAchievements.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4 flex items-center gap-2">
              <span>🔒</span> Locked
            </h3>
            <div className="grid gap-3">
              {lockedAchievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className="flex items-center p-4 bg-gray-100 rounded-xl border-2 border-gray-200 opacity-60"
                >
                  <div className="text-3xl mr-4 grayscale">{achievement.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-gray-600">
                        {achievement.name}
                      </h4>
                      <div 
                        className="w-3 h-3 rounded-full opacity-50"
                        style={{ backgroundColor: categoryColors[achievement.category] }}
                      />
                    </div>
                    <p className="text-sm text-gray-500">
                      {achievement.description}
                    </p>
                  </div>
                  <div className="text-2xl">🔒</div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-8">
          <button
            onClick={onClose}
            className="w-full px-6 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary-hover)] text-[var(--color-text)] font-semibold rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
