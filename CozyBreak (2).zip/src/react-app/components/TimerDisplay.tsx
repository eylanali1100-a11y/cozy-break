interface TimerDisplayProps {
  timeRemaining: number;
  isVisible: boolean;
}

export default function TimerDisplay({ timeRemaining, isVisible }: TimerDisplayProps) {
  if (!isVisible) return null;

  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;

  return (
    <div className="text-center mb-8">
      <div className="text-6xl font-bold text-[#333333] mb-2 font-mono tracking-wider">
        {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
      </div>
      <p className="text-lg text-[#333333] opacity-70">
        until your next break
      </p>
    </div>
  );
}
