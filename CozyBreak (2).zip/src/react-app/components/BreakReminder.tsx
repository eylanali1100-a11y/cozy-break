import { BreakExercise } from '@/react-app/hooks/useBreakExercises';

interface BreakReminderProps {
  isVisible: boolean;
  onDone: () => void;
  onLater: () => void;
  exercise: BreakExercise | null;
  breakTimeRemaining?: number;
  isOnBreak?: boolean;
}

export default function BreakReminder({ 
  isVisible, 
  onDone, 
  onLater, 
  exercise, 
  breakTimeRemaining = 0,
  isOnBreak = false 
}: BreakReminderProps) {
  if (!isVisible) return null;

  const minutes = Math.floor(breakTimeRemaining / 60);
  const seconds = breakTimeRemaining % 60;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={(e) => e.stopPropagation()}
    >
      <div 
        className="bg-white rounded-3xl p-8 max-w-md w-full mx-4 shadow-2xl animate-pulse"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">{exercise?.icon || '👀'}</div>
          <h2 className="text-2xl font-bold text-[var(--color-text)] mb-4">
            {exercise?.name || 'Time to rest your eyes!'}
          </h2>
          
          {isOnBreak && breakTimeRemaining > 0 && (
            <div className="bg-[var(--color-primary)] rounded-xl p-3 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-[var(--color-text)] font-mono">
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </div>
                <div className="text-sm text-[var(--color-text)] opacity-80">
                  break time remaining
                </div>
              </div>
            </div>
          )}
          <p className="text-base text-[var(--color-text)] mb-4 opacity-90">
            Do this quick exercise:
          </p>
          <div className="text-left bg-[var(--color-accent)] rounded-2xl p-4 mb-4">
            <div className="space-y-2 text-sm text-[var(--color-text)]">
              {exercise?.steps.map((step, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="text-[var(--color-primary)] font-bold">{index + 1}.</span>
                  <span>{step.text} {step.duration && <strong>{step.duration}</strong>}</span>
                </div>
              )) || (
                <>
                  <div className="flex items-center gap-2">
                    <span className="text-[var(--color-primary)] font-bold">1.</span>
                    <span>Close your eyes <strong>10 seconds</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[var(--color-primary)] font-bold">2.</span>
                    <span>Look far <strong>20 seconds</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[var(--color-primary)] font-bold">3.</span>
                    <span>Roll eyes <strong>5 times</strong></span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex gap-4 justify-center">
          <button
            onClick={onDone}
            className="px-6 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary-hover)] text-[var(--color-text)] font-semibold rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95"
          >
            Done ✅
          </button>
          <button
            onClick={onLater}
            className="px-6 py-3 bg-white hover:bg-gray-50 text-[var(--color-text)] font-semibold rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95 border-2 border-[var(--color-border)]"
          >
            Later ⏳
          </button>
        </div>
      </div>
    </div>
  );
}
