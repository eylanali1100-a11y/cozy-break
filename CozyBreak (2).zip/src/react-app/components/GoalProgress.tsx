import { useGoals } from '@/react-app/hooks/useGoals';

export default function GoalProgress() {
  const { dailyGoal, weeklyGoal, getTodayBreaks, getWeeklyBreaks } = useGoals();
  
  const todayBreaks = getTodayBreaks();
  const weeklyBreaks = getWeeklyBreaks();
  
  const dailyProgress = Math.min((todayBreaks / dailyGoal) * 100, 100);
  const weeklyProgress = Math.min((weeklyBreaks / weeklyGoal) * 100, 100);

  return (
    <div className="bg-[var(--color-card-bg)] rounded-2xl p-6 shadow-lg mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-[var(--color-text)]">Break Goals</h3>
        <div className="text-2xl">🎯</div>
      </div>
      
      <div className="space-y-4">
        {/* Daily Goal */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-[var(--color-text)]">Today</span>
            <span className="text-sm text-[var(--color-text)] opacity-70">
              {todayBreaks}/{dailyGoal}
            </span>
          </div>
          <div className="w-full bg-[var(--color-accent)] rounded-full h-3">
            <div
              className="bg-[var(--color-primary)] h-3 rounded-full transition-all duration-500"
              style={{ width: `${dailyProgress}%` }}
            />
          </div>
          {todayBreaks >= dailyGoal && (
            <div className="text-xs text-[var(--color-primary)] font-medium mt-1">
              🎉 Daily goal achieved!
            </div>
          )}
        </div>

        {/* Weekly Goal */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-[var(--color-text)]">This Week</span>
            <span className="text-sm text-[var(--color-text)] opacity-70">
              {weeklyBreaks}/{weeklyGoal}
            </span>
          </div>
          <div className="w-full bg-[var(--color-accent)] rounded-full h-3">
            <div
              className="bg-[var(--color-primary)] h-3 rounded-full transition-all duration-500"
              style={{ width: `${weeklyProgress}%` }}
            />
          </div>
          {weeklyBreaks >= weeklyGoal && (
            <div className="text-xs text-[var(--color-primary)] font-medium mt-1">
              🏆 Weekly goal achieved!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
