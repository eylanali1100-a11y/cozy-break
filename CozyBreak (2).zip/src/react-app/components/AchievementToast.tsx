import { Achievement } from '@/react-app/hooks/useAchievements';

interface AchievementToastProps {
  achievements: Achievement[];
  onDismiss: () => void;
}

export default function AchievementToast({ achievements, onDismiss }: AchievementToastProps) {
  if (achievements.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {achievements.map((achievement) => (
        <div
          key={achievement.id}
          className="bg-[var(--color-card-bg)] border-2 border-[var(--color-primary)] rounded-2xl p-4 shadow-2xl transform animate-pulse max-w-sm achievement-toast"
        >
          <div className="flex items-center gap-3">
            <div className="text-3xl">{achievement.icon}</div>
            <div className="flex-1">
              <h3 className="font-bold text-[var(--color-text)] text-sm">
                🎉 Achievement Unlocked!
              </h3>
              <div className="font-semibold text-[var(--color-primary)] text-base">
                {achievement.name}
              </div>
              <div className="text-xs text-[var(--color-text)] opacity-70 mt-1">
                {achievement.description}
              </div>
            </div>
            <button
              onClick={onDismiss}
              className="text-[var(--color-text)] hover:text-[var(--color-primary)] text-lg"
            >
              ×
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
