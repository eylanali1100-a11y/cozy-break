interface ActionButtonProps {
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
}

export default function ActionButton({ 
  onClick, 
  disabled = false, 
  children, 
  variant = 'primary' 
}: ActionButtonProps) {
  const baseClasses = "px-8 py-4 text-lg font-semibold rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-md";
  
  const variantClasses = variant === 'primary' 
    ? "bg-[var(--color-primary)] hover:bg-[var(--color-primary-hover)] text-[var(--color-text)]"
    : "bg-white hover:bg-gray-50 text-[var(--color-text)] border-2 border-[var(--color-border)]";

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variantClasses}`}
    >
      {children}
    </button>
  );
}
