interface TimerPresetsProps {
  onSelectPreset: (minutes: number) => void;
  disabled?: boolean;
  currentMinutes: number;
}

export default function TimerPresets({ onSelectPreset, disabled = false, currentMinutes }: TimerPresetsProps) {
  const presets = [
    { label: '15m', value: 15 },
    { label: '20m', value: 20 },
    { label: '30m', value: 30 },
    { label: '45m', value: 45 },
    { label: '60m', value: 60 },
  ];

  return (
    <div className="flex gap-2 justify-center flex-wrap">
      {presets.map((preset) => (
        <button
          key={preset.value}
          onClick={() => onSelectPreset(preset.value)}
          disabled={disabled}
          className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
            currentMinutes === preset.value
              ? 'bg-[var(--color-primary)] text-[var(--color-text)] shadow-md'
              : 'bg-white text-[var(--color-text)] border-2 border-[var(--color-accent)] hover:border-[var(--color-border)] shadow-sm'
          } disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95`}
        >
          {preset.label}
        </button>
      ))}
    </div>
  );
}
