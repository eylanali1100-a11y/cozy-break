interface StreakDisplayProps {
  currentStreak: number;
  totalBreaks: number;
  longestStreak: number;
}

export default function StreakDisplay({ currentStreak, totalBreaks, longestStreak }: StreakDisplayProps) {
  return (
    <div className="bg-[var(--color-card-bg)] rounded-2xl p-6 shadow-lg mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-[var(--color-text)]">Your Progress</h3>
        <div className="text-2xl">🔥</div>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-[var(--color-primary)]">{currentStreak}</div>
          <div className="text-sm text-[var(--color-text)] opacity-70">Day Streak</div>
        </div>
        
        <div className="text-center">
          <div className="text-2xl font-bold text-[var(--color-primary)]">{totalBreaks}</div>
          <div className="text-sm text-[var(--color-text)] opacity-70">Total Breaks</div>
        </div>
        
        <div className="text-center">
          <div className="text-2xl font-bold text-[var(--color-primary)]">{longestStreak}</div>
          <div className="text-sm text-[var(--color-text)] opacity-70">Best Streak</div>
        </div>
      </div>
      
      {currentStreak > 0 && (
        <div className="mt-4 text-center">
          <div className="text-sm text-[var(--color-text)] opacity-80">
            🎉 You're on a {currentStreak}-day streak! Keep it up!
          </div>
        </div>
      )}
    </div>
  );
}
